function showModalSearch() {
  document.getElementById("showModalSearch").style.display = "block";
  document.getElementById("opacitiScreen").style.display = "block";
}
function closeScreen() {
  document.getElementById("showModalSearch").style.display = "none";
  document.getElementById("opacitiScreen").style.display = "none";
}
