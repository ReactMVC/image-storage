var READTHEDOCS_DATA = {
    "project": "django-advanced-training", 
    "theme": "readthedocs", 
    "version": "latest", 
    "source_suffix": ".md", 
    "api_host": "https://readthedocs.org", 
    "language": "en", 
    "commit": "c85dea3a8972900e284663d2ad2affc1b133a336", 
    "docroot": "/home/docs/checkouts/readthedocs.org/user_builds/django-advanced-training/checkouts/latest/docs", 
    "builder": "mkdocs", 
    "page": null
}

// Old variables
var doc_version = "latest";
var doc_slug = "django-advanced-training";
var page_name = "None";
var html_theme = "readthedocs";

READTHEDOCS_DATA["page"] = mkdocs_page_input_path.substr(
    0, mkdocs_page_input_path.lastIndexOf(READTHEDOCS_DATA.source_suffix));
