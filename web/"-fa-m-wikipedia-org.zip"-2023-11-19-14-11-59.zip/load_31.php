<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20"><title>
		menu
	</title><g fill="#fff"><path d="M1 3v2h18V3zm0 8h18V9H1zm0 6h18v-2H1z"/></g></svg>
