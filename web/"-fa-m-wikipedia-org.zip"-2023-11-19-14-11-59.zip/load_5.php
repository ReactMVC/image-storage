<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10"><g fill="#69f">
	<path d="M1.1 8.9h7.8V1.1H6.1V0h2.8c.6 0 1.1.5 1.1 1.1v7.8c0 .6-.5 1.1-1.1 1.1H1.1C.5 10 0 9.5 0 8.9V6.1h1.1v2.8z"/>
	<path d="M0 0h4.4L2.6 1.8 5.8 5l-.8.8-3.2-3.2L0 4.4V0z"/>
</g></svg>
