$(document).ready(function(){
	
	
	
/* ----- Home Ajax Search ----------------------------------- */
	
	$("#searchinput").keyup(function () {
		
		var minlength = 3;
		value = $("#searchinput").val();
		if (value.length >= minlength ) {
				$('#searchResult').show();
				$('#searchResult').html( '<div class="text-center">درحال جستجو ...</div>' );
				
				$.ajax({
					url: ajaxurl,
					type: 'post',
					data: {
						action: 'ajaxSearch',
						searchQuery: $('#searchinput').val()
					},
					success: function (data) {
						$('#searchResult').html(data);
					},
					error: function() {
						//alert('There was some error performing the AJAX call!');
					}
				});

		} else {
			$('#searchResult').html( '' );
			$('#searchResult').hide();
		}
	});
	
	
	
	
	
	
	
});