//side panel codes
var menuSwitch = document.querySelector(".menu_switch");
menuSwitch.addEventListener("click", (click) => {
  var nav = document.querySelector("#nav");
  var menu = document.querySelector(".header--nav");
  menu.classList.toggle("show");
  nav.classList.add("scroll");
  if (menu.classList.contains("show")) {
    var darkBox = document.createElement("div");
    darkBox.className = "dark-box";
    document.body.prepend(darkBox);
    darkBox.addEventListener("click", (click) => {
      menu.classList.remove("show");
      nav.classList.remove("scroll");
      darkBox.parentNode.removeChild(darkBox);
    });
  } else {
    var darkRemove = document.querySelector(".dark-box");
    darkRemove.parentNode.removeChild(darkRemove);
  }
});

//show hide panel and menu
var showBtn = document.querySelectorAll(".show-btn");
showBtn.forEach((element) => {
  element.addEventListener("click", (click) => {
    element.nextElementSibling.classList.toggle("show");
    document.addEventListener("click", (click) => {
      if (click.target != element) {
        if (click.target != element.querySelector("svg")) {
          element.nextElementSibling.classList.remove("show");
        }
      }
    });
  });
});
