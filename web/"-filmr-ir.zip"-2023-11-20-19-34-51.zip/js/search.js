let searchBtn = document.querySelector("#searchbtn");
searchBtn.addEventListener("click", (click) => {
  document.querySelector('#search--nav').style.display = 'flex';
  document.querySelector('.searchform > input').focus();
});
let searchBtnHide = document.querySelector("#searchbtn-hide");
searchBtnHide.addEventListener("click", (click) => {
  document.querySelector('#search--nav').style.display = 'none';
});