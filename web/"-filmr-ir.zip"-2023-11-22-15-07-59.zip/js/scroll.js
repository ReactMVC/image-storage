//start single scrool on click
const anchors = document.querySelectorAll('a[data-target^="anchor"]');
for (let anchor of anchors) {
	anchor.addEventListener("click", function(e) {
		e.preventDefault();
		const sectionTarget = anchor.getAttribute("href");
		let targetOffset = document.querySelector(""+sectionTarget).offsetTop  - 66;
		window.scrollTo({
			top: targetOffset,
			behavior: "smooth"
		});
	});
}
//srart progrees bar
function progressBarScroll() {
  let winScroll = document.body.scrollTop || document.documentElement.scrollTop,
      height = document.documentElement.scrollHeight - document.documentElement.clientHeight,
      scrolled = (winScroll / height) * 100;
  document.getElementById("progressBar").style.width = scrolled + "%";
}
//start navbar back
var scrollPos = 0;
var nav = document.getElementById("nav");
//start mix to geder
window.onscroll = function () {
  progressBarScroll();
  if (window.scrollY > 1) {
    nav.classList.add("scroll");
    nav.classList.remove("normal");
  } else {
    nav.classList.add("normal");
    nav.classList.remove("scroll");
  }
};
window.onload = function () {
	if (window.scrollY > 1) {
    nav.classList.add("scroll");
    nav.classList.remove("normal");
  } else {
    nav.classList.add("normal");
    nav.classList.remove("scroll");
  }
}