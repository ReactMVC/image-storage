document.addEventListener('DOMContentLoaded', function () {
	// Let's check if the browser supports notifications
	if (!("Notification" in window)) {
		// This browser does not support desktop notification
		return;
	}

	let installPromptEvent;
	if ("serviceWorker" in navigator) {
		navigator.serviceWorker.register("/sw.js?v=14001011").then(
			function (sw){
				// console.log(sw);
			}
		);

		window.addEventListener('beforeinstallprompt' , function (e) {
			installPromptEvent = e;
		});
	}

	function checkSupportPwaBrowser(){
		let browser_user_firefox = navigator.userAgent.match(/firefox|fxios/i);

		if(browser_user_firefox){
			$(".toast-install-pwa").text("برای نصب این برنامه  باید از مرورگر های opera , chrome یا edge استفاده کنید.").toast('show');
			return false;
		}
		return true;
	}

	$(document).off('click', '.btn-install-pwa');
	$(document).on('click', '.btn-install-pwa', function (e) {
		e.preventDefault();
		let check_support_browser = checkSupportPwaBrowser();
		if(installPromptEvent && check_support_browser === true) {
			installPromptEvent.prompt();// two type : accepted && dismissed
			installPromptEvent.userChoice
				.then((choiceResult) => {
					if(choiceResult.outcome === 'accepted') {
						initStatistic('cpwa', 0);
						localStorage.setItem('install_pwa', 'accepted');
					}else{
						initStatistic('cpwa', 1);
						setCookie('install_pwa', 'no', 7);
					}
					installPromptEvent = null;
				})
		}else {
			$(".toast-install-pwa").toast('show');
		}
	});

	let permission = Notification.permission; // granted, default, denied

	var pushPermissionCookie = getCookie('push_permission');
	if(permission === 'default' && window.master_vars.must_have_push === '1' && pushPermissionCookie !== 'no'){
		if(window.master_vars.have_specific_role === '1') {
			toast(window.master_vars.user_full_name + ' گرامی، آيا تمایل دارید که اطلاع رسانی های سایت را سریعا به شما اطلاع رسانی کنیم؟<br>در صورت تمایل در مرحله بعد، گزینه Allow را انتخاب نمائید', 'success', false, 'center', 'btn_subscribe_push');
		} else {
			// کاربران معمولی
			toast(window.master_vars.user_full_name + ' گرامی آيا تمایل دارید که پاسخ پزشک را سریعا به شما اطلاع رسانی کنیم؟<br>در صورت تمایل در مرحله بعد، گزینه Allow را انتخاب نمائید', 'success', false, 'center', 'btn_subscribe_push');
		}
		// در صورت تایید این پیغام، تابع initSW فراخوانی می شود
	}
});

function initSW() {
	if (!"serviceWorker" in navigator) {
		// service worker isn't supported
		return;
	}

	// don't use it here if you use service worker for other stuff.
	if (!"PushManager" in window) {
		//push isn't supported
		return;
	}

	navigator.serviceWorker.register('/sw.js?v=14001011')
		.then(() => {
			initPush();
		})
		.catch((err) => {
			// console.log(err);
		});
}

function initPush() {
	if (!navigator.serviceWorker.ready) {
		return;
	}

	new Promise(function (resolve, reject) {
		const permissionResult = Notification.requestPermission(function (result) {
			resolve(result);
		});

		if (permissionResult) {
			permissionResult.then(resolve, reject);
		}
	})
		.then((permissionResult) => {
			if (permissionResult !== 'granted') {
				initStatistic('cpa', 2);
				throw new Error('We weren\'t granted permission.');
			} else {
				subscribeUser();
			}
		});
}

function subscribeUser() {
	navigator.serviceWorker.ready
		.then((registration) => {
			const subscribeOptions = {
				userVisibleOnly: true,
				applicationServerKey: urlBase64ToUint8Array(window.VAPID_PUBLIC_KEY)
			};

			return registration.pushManager.subscribe(subscribeOptions);
		})
		.then((pushSubscription) => {
			storePushSubscription(pushSubscription);
		});
}

function urlBase64ToUint8Array(base64String) {
	var padding = '='.repeat((4 - base64String.length % 4) % 4);
	var base64 = (base64String + padding)
		.replace(/\-/g, '+')
		.replace(/_/g, '/');

	var rawData = window.atob(base64);
	var outputArray = new Uint8Array(rawData.length);

	for (var i = 0; i < rawData.length; ++i) {
		outputArray[i] = rawData.charCodeAt(i);
	}
	return outputArray;
}

function storePushSubscription(pushSubscription) {
	const token = document.querySelector('meta[name=csrf-token]').getAttribute('content');

	fetch('/push', {
		method: 'POST',
		body: JSON.stringify(pushSubscription),
		headers: {
			'Accept': 'application/json',
			'Content-Type': 'application/json',
			'X-CSRF-Token': token
		}
	})
		.then((res) => {
			return res.json();
		})
		.then((res) => {
			// console.log(res);
			storeGuestIdForComment(res);
		})
		.catch((err) => {
			// console.log(err);
		});
}

function storeGuestIdForComment(res) {
	if(res.data.subscription_user_type === 'guests') {
		initPostRequest(window.master_vars.url_store_comment_guest_id, {'comment_id' : window.master_vars.last_inserted_comment_id, 'guest_id' :  res.data.subscription_user_id}).then((response) => {
			// if (typeof response !== 'undefined' && response.success){
			//
			// }
		});
	}
}
