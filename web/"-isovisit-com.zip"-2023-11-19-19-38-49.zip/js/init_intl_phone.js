// div_selector is mandatory
// iso2 is optional and used in edit form
// mobile_number is optional and used in edit form

function initIntlPhone(div_selector, iso2, mobile_number) {
	//ایزو2 برای ویرایش استفاده می شود تا کشور پیشفرض را انتخاب کند.
	iso2 = iso2 || 'ir';
	mobile_number = mobile_number || '';
	let intl_phone_div = '' +
		'<div>' +
		'	<input type="hidden" id="intl_phone_iso2" name="iso2" />' +
		'	<input type="hidden" id="intl_dial_code_send" name="dial_code" />' +
		'	<input type="text" class="intl_dial_code" id="intl_dial_code_show" readonly />' +
		'	<input type="tel" class="intl_phone none_eng" id="intl_mobile" name="mobile" value="'+ mobile_number +'">' +
		'</div>';
	$(div_selector).html(intl_phone_div);

	let mobile = document.querySelector('#intl_mobile');
	let number = window.intlTelInput(mobile, {
		initialCountry: 'ir',
		preferredCountries: ['ir'],
		utilsScript: '/admin/vendors/intl-tell-input/js/utils.js'
	});
	number.setCountry(iso2);
	$('#intl_phone_iso2').val(number.getSelectedCountryData().iso2);
	$('#intl_dial_code_send').val(number.getSelectedCountryData().dialCode);
	$('#intl_dial_code_show').val('+' + number.getSelectedCountryData().dialCode);
	mobile.addEventListener("countrychange", function () {
		$('#intl_phone_iso2').val(number.getSelectedCountryData().iso2);
		$('#intl_dial_code_send').val(number.getSelectedCountryData().dialCode);
		$('#intl_dial_code_show').val('+' + number.getSelectedCountryData().dialCode);
	});
}
