// Variables

const p2e = s => s.replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d))

const otpInputs = document.querySelectorAll(".otp__form input");
const otpSubmitBtn = document.querySelector(".otp__submit");

const userDataView = document.querySelector(".user-data");
const userDataForm = document.querySelector(".user-data__form");
const userDataSubmit = document.querySelector(".user-data__submit");
const userDataPhone = document.querySelector(".user-data__phone");

const otpView = document.querySelector(".otp");
const otpForm = document.querySelector(".otp__form");
const otpSubmit = document.querySelector(".otp__submit");

const backwardBtn = document.querySelector(".backward-btn");

// Event Listeners
userDataForm.addEventListener("submit", (e) => {
    e.preventDefault();
    userDataPhone.value = p2e(userDataPhone.value);
    if (!/0?(9\d{9})/.test(userDataPhone.value)) {
        showNotification("خطا", "لطفا یک شماره موبایل معتبر وارد کنید.", "danger", 4000);
        return;
    }
    $(".otp-phone__text").text(userDataPhone.value);
    $(userDataSubmit).showLoader("bounce");
    $(userDataPhone).prop("disabled", true);
    $.ajax({
        url: sthe.ajaxurl,
        type: "post",
        dataType: "json",
        data: {
            action: "sthe_login_otp",
            phone: userDataPhone.value
        },
        success: function(data) {
            $(userDataSubmit).hideLoader();
            $(userDataPhone).prop("disabled", false);
            if (data.success) {
                if (data.redirect) {
                    var url = new URL(window.location.href);
                    window.location.href = data.redirect+(url.searchParams.get("after") ? (data.redirect.indexOf("?") !== -1 ? "&" : "?")+"after="+encodeURIComponent(url.searchParams.get("after")) : "");
                    return;
                }
                userDataView.classList.add("hidden");
                otpView.classList.remove("hidden");
                if (data.msg) {
                    showNotification("موفق", data.msg, "success", 4000);
                } else {
                    showNotification("موفق", "کد تایید به شماره موبایل وارد شده ارسال شد.", "success");
                }
                otpResendTimer(data.resend_wait);
                otpHandler(otpInputs);
            } else if (data.msg) {
                showNotification("خطا", data.msg, "danger", 5000);
            } else {
                showNotification("خطا", "خطای غیرمنتظره‌ای رخ داد.", "danger", 5000);
            }
        },
        error: function() {
            $(userDataSubmit).hideLoader();
            $(userDataPhone).prop("disabled", false);
            showNotification("خطا", "خطای غیرمنتظره‌ای رخ داد.", "danger", 5000);
        },
    });
})
backwardBtn.addEventListener("click", () => {
    otpView.classList.add("hidden");
    userDataView.classList.remove("hidden");
    otpInputs.forEach((input) => {
        input.value = "";
    })
})
// Functions
function otpHandler(otpInputs){
    let lastOtpInput = otpInputs[otpInputs.length - 1];
    otpInputs[0].focus();
    otpInputs.forEach((input) => {
        input.addEventListener("input", () => {
            let currentInput = input;
            let nextInput = input.nextElementSibling;
            currentInput.value = p2e(currentInput.value);
            currentInput.value = currentInput.value.replace(/[^0-9]/g);
            if (currentInput.value.length > 1){
                currentInput.value = ""
            }
            if (nextInput !== null && currentInput.value !== "") {
                nextInput.focus()
            }
            if (nextInput !== null && nextInput.value)
                nextInput.setSelectionRange(0, nextInput.value.length)
            if (lastOtpInput.value !== "") {
                otpSubmitBtn.click();
            }
        })
        input.addEventListener('keydown', function(event) {
            var key = event.keyCode || event.charCode;
            if (key == 8 || key == 46) {
                input.value = "";
                if (input.previousElementSibling)
                    input.previousElementSibling.focus();
            }
        });
    })
}

function otpResendTimer(sec) {
    var func = () => {
        let minute = parseInt(sec/60)
        let second = sec % 60;
        if (sec <= 0) {
            $(".user-otp__resend").removeClass("disabled");
            $(".user-otp__resend .timer").addClass("hidden");
            clearInterval(timer);
        } else {
            $(".user-otp__resend").addClass("disabled");
            $(".user-otp__resend .timer").removeClass("hidden");
            $(".user-otp__resend .timer .minute").text(String(minute).padStart(2, "0"));
            $(".user-otp__resend .timer .second").text(String(second).padStart(2, "0"));
            sec--;
        }
    };
    func();
    var timer = setInterval(func, 1000)
}

otpForm.addEventListener("submit", (e) => {
    e.preventDefault();
    let otp = "";
    otpInputs.forEach((input) => {
        otp += input.value;
    });
    if (otp.length !== 5) {
        showNotification("خطا", "لطفا کد را کامل وارد کنید.", "danger", 4000);
        return;
    }
    $(otpSubmitBtn).showLoader("bounce");
    $(otpInputs).prop("disabled", true);
    $.ajax({
        url: sthe.ajaxurl,
        type: "post",
        dataType: "json",
        data: {
            action: "sthe_verify_otp",
            phone: userDataPhone.value,
            otp: otp
        },
        success: function(data) {
            $(otpSubmitBtn).hideLoader();
            $(otpInputs).prop("disabled", false);
            if (data.success) {
                showNotification("موفق", "با موفقیت وارد شدید.", "success");
                window.location.href = $("#after_url").val();
            } else if (data.msg) {
                showNotification("خطا", data.msg, "danger", 5000);
            } else {
                showNotification("خطا", "خطای غیرمنتظره‌ای رخ داد.", "danger", 5000);
            }
        },
        error: function() {
            $(otpSubmitBtn).hideLoader();
            $(otpInputs).prop("disabled", false);
            showNotification("خطا", "خطای غیرمنتظره‌ای رخ داد.", "danger", 5000);
        },
    });
});

$(".user-otp__resend").click(() => {
    if ($(".user-otp__resend").hasClass("disabled"))
        return;
    $(otpSubmitBtn).showLoader("bounce");
    $(".user-otp__resend").addClass("disabled");
    $.ajax({
        url: sthe.ajaxurl,
        type: "post",
        dataType: "json",
        data: {
            action: "sthe_resend_otp",
            phone: userDataPhone.value,
        },
        success: function(data) {
            $(otpSubmitBtn).hideLoader();
            $(".user-otp__resend").removeClass("disabled");
            if (data.success) {
                showNotification("موفق", "کد تایید دوباره با موفقیت ارسال شد.", "success");
            } else if (data.msg) {
                showNotification("خطا", data.msg, "danger", 5000);
            } else {
                showNotification("خطا", "خطای غیرمنتظره‌ای رخ داد.", "danger", 5000);
            }
            if (data.resend_wait) {
                otpResendTimer(data.resend_wait);
            }
        },
        error: function() {
            $(otpSubmitBtn).hideLoader();
            $(".user-otp__resend").removeClass("disabled");
            showNotification("خطا", "خطای غیرمنتظره‌ای رخ داد.", "danger", 5000);
        },
    });
});

if (userDataPhone.value.length > 0) {
    $(userDataSubmit).click();
}